package com.nttdata.Proyecto_transaccion;

import com.nttdata.Proyecto_transaccion.api.TransaccionesApiDelegate;
import com.nttdata.Proyecto_transaccion.bussines.TransaccionService;
import com.nttdata.Proyecto_transaccion.model.TransaccionResponse;
import lombok.SneakyThrows;
import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransaccionDelegateImp implements TransaccionesApiDelegate {


    @Autowired
    TransaccionService transaccionService;

    @Override
    public ResponseEntity<TransaccionResponse> depositar(TransaccionResponse transaccionResponse) {
        validateDepositOrRetiro(transaccionResponse);
        transaccionResponse.setTipo("DEPOSITO");
        return ResponseEntity.ok(transaccionService.depositar(transaccionResponse));
    }

    @Override
    public ResponseEntity<List<TransaccionResponse>> hisotrial() {
        return ResponseEntity.ok(transaccionService.hisotrial());
    }

    @Override
    public ResponseEntity<TransaccionResponse> retirar(TransaccionResponse transaccionResponse) {
        validateDepositOrRetiro(transaccionResponse);
        transaccionResponse.setTipo("RETIRO");
        return ResponseEntity.ok(transaccionService.retirar(transaccionResponse));
    }

    @Override
    public ResponseEntity<TransaccionResponse> transferencia(TransaccionResponse transaccionResponse) {
        validateTransferencia(transaccionResponse);
        transaccionResponse.setTipo("TRANSFERENCIA");
        return ResponseEntity.ok(transaccionService.transferencia(transaccionResponse));
    }

    @SneakyThrows
    private void validateDepositOrRetiro(TransaccionResponse transaccionResponse) {
        if (transaccionResponse.getCuentaDestino() != null && !transaccionResponse.getCuentaDestino().isEmpty()) {
            throw new BadRequestException("La cuenta destino no es requerida para depositos y retiros");
        }
        if (transaccionResponse.getCuentaOrigen() == null || transaccionResponse.getCuentaOrigen().isEmpty()) {
            throw new BadRequestException("La cuenta origen es requerida");
        }
    }

    @SneakyThrows
    private void validateTransferencia(TransaccionResponse transaccionResponse) {
        if (transaccionResponse.getCuentaOrigen() != null && !transaccionResponse.getCuentaOrigen().isEmpty()) {
            throw new BadRequestException("La cuenta origen no es requerida para transferencias");
        }
        if (transaccionResponse.getCuentaDestino() == null || transaccionResponse.getCuentaDestino().isEmpty()) {
            throw new BadRequestException("La cuenta destino es requerida");
        }
    }

}
