package com.nttdata.Proyecto_transaccion.bussines;

import com.nttdata.Proyecto_transaccion.model.TransaccionResponse;
import com.nttdata.Proyecto_transaccion.model.entity.Transaccion;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

@Component
public class TransaccionMapper {

    public Transaccion getTransaccionEntity (TransaccionResponse request){
        Transaccion entity = new Transaccion();
        entity.setTipo(request.getTipo());
        entity.setMonto(request.getMonto());
        entity.setFecha(LocalDateTime.now(ZoneId.of("America/Lima")));
        entity.setCuentaOrigen(request.getCuentaOrigen());
        entity.setCuentaDestino(request.getCuentaDestino());
        return  entity;

    }

    public TransaccionResponse getTransaccionResponse (Transaccion entity){
        TransaccionResponse response = new TransaccionResponse();
        response.setTipo(entity.getTipo());
        response.setMonto(entity.getMonto());
        response.setFecha(entity.getFecha());
        response.setCuentaOrigen(entity.getCuentaOrigen());
        response.setCuentaDestino(entity.getCuentaDestino());
        return  response;





    }
}
