package com.nttdata.Proyecto_transaccion.model.entity;


import lombok.Data;
import nonapi.io.github.classgraph.json.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Data
@Document(collection = "transacciones")
public class Transaccion {

    @Id
    private String idTransacciones;
    private String tipo;
    private BigDecimal monto;
    private LocalDateTime fecha;
    private  String cuentaOrigen;
    private String cuentaDestino;

}
