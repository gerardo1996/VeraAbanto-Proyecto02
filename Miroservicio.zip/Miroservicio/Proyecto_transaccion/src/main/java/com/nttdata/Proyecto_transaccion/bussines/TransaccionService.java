package com.nttdata.Proyecto_transaccion.bussines;

import com.nttdata.Proyecto_transaccion.model.TransaccionResponse;
import com.nttdata.Proyecto_transaccion.model.entity.Transaccion;

import java.util.List;

public interface TransaccionService {

    public List<TransaccionResponse> hisotrial();
    public TransaccionResponse depositar(TransaccionResponse transaccionResponse);
    public TransaccionResponse retirar(TransaccionResponse transaccionResponse);
    public TransaccionResponse transferencia (TransaccionResponse transaccionResponse);

}
